https://github.com/recotana/ArdOSC/


===================================================


for Arduino firmware 1.0

tested Arduino Ethernet
http://www.arduino.cc/en/Main/ArduinoBoardEthernet

Installation
ArdOSC folder into ..

Mac
~/Documents/Arduino/libraries/

Win
MyDocuments\Arduino\libraries\

http://www.arduino.cc/en/Hacking/Libraries


===================================================


 ArdOSC 2.1  - OSC Library for Arduino.
 
 This library works with arduino firmware0022.
 2011/09/19 version 2.1 added callback function
                        added osc message argument function
 2010/02/01 version 2.0 changed Project OSCClass -> ArdOSC
 2009/03/22 version 1.0.1 add errror process。change Doc.
 2009/03/21 version 1.0.0
